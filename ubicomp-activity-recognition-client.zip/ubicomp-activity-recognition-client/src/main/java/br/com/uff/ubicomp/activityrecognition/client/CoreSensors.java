package br.com.uff.ubicomp.activityrecognition.client;
 
import java.net.InetSocketAddress;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CoreSensors
{
	  
    private static final String	   gatewayIP   = "127.0.0.1";
    private static final int       gatewayPort = 5500;
    
    private static CoreSensors me;
    
    private final SensorBathRoom     sensorBathRoom;
    private final SensorBedRoom      sensorBedRoom;
    private final SensorExternalArea sensorExternalArea;
    private final SensorKitchen      sensorKitchen;
    private final SensorLivingRoom   sensorLivingRoom;
    private final SensorUserPosition sensorUserPosition;
    
    public static void main(String[] args) 
    {
        Logger.getLogger("").setLevel(Level.OFF);
        me = new CoreSensors();
    }
	 
    public CoreSensors() 
    {
        InetSocketAddress address = new InetSocketAddress(gatewayIP, gatewayPort);
        
        sensorBathRoom = new SensorBathRoom(address);
        sensorBedRoom = new SensorBedRoom(address);
        sensorExternalArea = new SensorExternalArea(address);
        sensorKitchen = new SensorKitchen(address);
        sensorLivingRoom = new SensorLivingRoom(address);
        sensorUserPosition = new SensorUserPosition(address);
        
        sensorBathRoom.start();
        sensorBedRoom.start();
        sensorExternalArea.start();
        sensorKitchen.start();
        sensorLivingRoom.start();
        sensorUserPosition.start();
    }  
}


