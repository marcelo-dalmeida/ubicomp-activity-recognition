package br.com.uff.ubicomp.activityrecognition.client.smarthome;

public enum Activity {
	READING, EATING, COOKING, SLEEPING, WATCHING_TV, WORKING_WITH_PC, LEAVING, BATHING, WASHING_DISHES, CLEANING_THE_HOUSE;
}
